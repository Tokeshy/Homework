from rss_reader import RunIt

if __name__ == "__main__":
    RunIt()